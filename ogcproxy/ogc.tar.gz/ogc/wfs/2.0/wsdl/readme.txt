The intention here is that individual implementations will declare something
like ?-endpoints.wsdl, and will provide restricted versions of ?-bindings.wsdl,
depending on the interfaces that the implementation supports.

The file WSDL2Java.bat generates an Axis 1.1 service.
(It should work with Axis 1.2 also.)

