OpenGIS(r) TML schema - ReadMe.txt
==================================

OpenGIS Transducer Markup Language (TML) Encoding Standard

More information on the OGC TML standard may be found at
 http://www.opengeospatial.org/standards/tml

The most current schema are available at http://schemas.opengis.net/ .

-----------------------------------------------------------------------

2010-02-01  Kevin Stegemoller

  * v1.0.0: create/update ReadMe.txt (06-135r7 s#17)

2007-06-29  Steve Havens 

  * added TML 1.0.0 (OGC 06-010r6 )

-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/legal/ .

Copyright (c) 2010 Open Geospatial Consortium, Inc. All Rights Reserved.

-----------------------------------------------------------------------

