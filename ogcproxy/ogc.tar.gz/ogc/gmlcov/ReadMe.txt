-----------------------------------------------------------------------
OpenGIS(r) GML Coverages Application Schema - ReadMe.txt
-----------------------------------------------------------------------

The GML Coverages Application Schema are defined in the OGC document 09-146r1.

More information on the OGC GML WCS AppSchema standard may be found at
 http://www.opengeospatial.org/standards/gml

The most current schema are available at http://schemas.opengis.net/ .

-----------------------------------------------------------------------

2010-11-05  Peter Baumann

  * v1.0: added gmlcov 1.0.0 (OGC 09-146r1)

  * Note: check each OGC numbered document for detailed changes.

-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/legal/ .

Copyright (c) 2010 Open Geospatial Consortium, Inc. All Rights Reserved.

-----------------------------------------------------------------------

