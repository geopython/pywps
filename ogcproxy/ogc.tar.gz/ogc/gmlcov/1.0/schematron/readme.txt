These Schematron files serve to check conformance of a coverage instance document.
They are provided for information purposes only. Some of them check only part of
the requirements, and some of them do not execute in the form provided, due to
technical constraints of Schematron.
Still, they may serve as hints on how to write tests.

Last updated: 2010-apr-14
Copyright (c) 2010 Open Geospatial Consortium, Inc, All Rights Reserved.
To obtain additional rights of use, visit http://www.opengeospatial.org/legal/.

