OpenGIS(r) SWE Common - ReadMe.txt
==================================

OpenGIS(r) Sensor Web Enablement (SWE) Common data types

The SWE Common schema were approved as Version 1.0.0 by the OGC membership on
23 June 2007.  They are defined in the OGC SensorML document 07-000.
Corrigendum 1 (OGC 07-122r2) made changes to these and were released as
sweCommon 1.0.1.

More information on the OGC SensorML standard may be found at
 http://www.opengeospatial.org/standards/sensorml

The most current schema are available at http://schemas.opengis.net/ .

-----------------------------------------------------------------------

2010-02-01  Kevin Stegemoller

	* v1.0.1, v1.0.0:
    + updated xsd:schema:@version attribute (06-135r7 s#13.4)
    + update relative schema imports to absolute URLs (06-135r7 s#15)
    + update/verify copyright (06-135r7 s#3.2)
    + add archives (.zip) files of previous versions
    + create/update ReadMe.txt (06-135r7 s#17)

2007-11-12  Kevin Stegemoller

  * v1.0.1: post sweCommon/1.0.1 - OGC 07-000 + 07-122r2 
  * v1.0.1: added copyright statement
  * v1.0.1: minor documentation changes
  * see ChangeLog.txt for additional details


-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/legal/ .

Copyright (c) 2010 Open Geospatial Consortium, Inc. All Rights Reserved.

-----------------------------------------------------------------------

