19139 XSchemas TS RC (2006 May 4)
-----------------------------------------------

OGC GML 3.2.0 version => ISO 19136 XSchemas DIS (2005 november)
 -- http://www.isotc211.org/2005/

These schemas from ISO 19139 version 2005-DIS (Draft International Standard)
dated 2006 May 4. For the sake of convenience, GML 3.2 XML schemas (version
19136 DIS - 2005 november) are (temporarily) provided with the 19139 set of
schemas. They were retrieved from http://www.isotc211.org/2005/ . Once these
schemas are finalized they will become OGC GML 3.2.1 and ISO/TS 19136.

Changes made to these ISO 19139 schemas by OGC:
  * changed xlink references from relative to absolute
    so they use http://schemas.opengis.net/xlink/1.0.0/xlinks.xsd .
  * update relative schema imports to absolute URLs (OGC 06-135r7 s#15)
  
-- Kevin Stegemoller 2010-01-29

Changes made to these ISO 19139 schemas by OGC:
  * changed xlink references from ../xlink/xlinks.xsd to ../../../../xlink/1.0.0/xlinks.xsd
    so they use http://schemas.opengis.net/xlink/1.0.0/xlinks.xsd .
  * removed xlinks directory and schema
  * replaced 19139-GML_readme.txt with this document.

-- Kevin Stegemoller 2007-08-14
