OpenGIS(r) Sampling 1.0.0 - ReadMe.txt
======================================

-----------------------------------------------------------------------

Observations and Measurements - Part 2 - Sampling Features (OGC 07-002r3)

More information on the OGC Sampling standard may be found at
 http://www.opengeospatial.org/standards/om

The most current schema are available at http://schemas.opengis.net/ .

-----------------------------------------------------------------------

2010-02-15  Simon Cox
  * reverted xsd:schema/@version attribute to 1.0.0 to align version with path
    and documentation.  The @version attribute for 1.0.1 will not be used. 

2010-01-21  Kevin Stegemoller 
  * v1.0: updated to sampling v.1.0.1
  * v1.0: update/verify copyright (06-135r7 s#3.2)
  * v1.0: update relative schema imports to absolute URLs (06-135r7 s#15)
  * v1.0: updated xsd:schema:@version attribute (06-135r7 s#13.4)
  * v1.0: add archives (.zip) files of previous versions
  * v1.0: create/update ReadMe.txt (06-135r7 s#17)

-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/legal/ .

Copyright (c) 2010 Open Geospatial Consortium, Inc. All Rights Reserved.

-----------------------------------------------------------------------
