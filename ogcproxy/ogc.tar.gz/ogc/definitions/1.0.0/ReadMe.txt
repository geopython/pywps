2007-06-20  Kevin Stegemoller

  * definitions/1.0.0: migrated Definitions 1.0.0 (OGC 05-010) to 1.0.0
    directory. A copy will remain here for historical purposes.
  * definitions/1.0.0: updated gml relative path locations for 
    Definitions/1.0.0 migration move
  * definitions/1.1.0: added Definitions 1.1.0 (OGC 06-023r1)

2005-11-22  Arliss Whiteside

  * v1.1.0, v1.0.0: The XML Schema Documents for OpenGIS(r) Definitions
    Versions have been edited to reflect the corrigenda to documents
    1.0.0 (OGC 05-010) which are based on the change requests: 
    OGC 05-068r1 "Store xlinks.xsd file at a fixed location"
    OGC 05-081r2 "Change to use relative paths"

