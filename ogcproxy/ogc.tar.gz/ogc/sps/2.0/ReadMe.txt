OpenGIS(r) Sensor Planning Service schema - ReadMe.txt
======================================================

OGC(r) Sensor Planning Service
-----------------------------------------------------------------------

Sensor Planning Service Implementation Standard.

The Sensor Planning Service 2.0 standard is defined in OGC document 09-000.

More information may be found at
 http://www.opengeospatial.org/standards/sps

The most current schema are available at http://schemas.opengis.net/ .

The root (all-components) XML Schema Document, which includes
directly and indirectly all the XML Schema Documents, defined by
Sensor Planning Service 2.0 is sps.xsd.

* Latest version is: http://schemas.opengis.net/sps/2.0/sps.xsd *

-----------------------------------------------------------------------


2011-03-28  Johannes Echterhoff

  * v2.0.0: Added sps/2.0 - OGC 09-000


-----------------------------------------------------------------------

Policies, Procedures, Terms, and Conditions of OGC(r) are available
  http://www.opengeospatial.org/ogc/legal/ .

Copyright (c) 2011 Open Geospatial Consortium, Inc. All Rights Reserved.

-----------------------------------------------------------------------
